<?php
#error_reporting(E_ALL | E_STRICT);

# READ LTISTAT.CSV
$fp = file('/home/pi/ltistat.csv');
#CHECK IF THERE IS MORE THAN ONE ENTRY; IF YES, READ LAST ENTRY TO GET CURRENT SPEED
if( count($fp) > 1 ){
	$rows = file('/home/pi/ltistat.csv');
	$last_row = array_pop($rows);
	$stat = str_getcsv($last_row);
	
	}else{
	$stat= file_get_contents('/home/pi/ltistat.csv');
	}
	#SUBSTRACT ONE CHARACHTER AS THERE MIGHT BE A BUG THAT THERE IS AN "INVISIBLE" CHARACHTER IN THE LTISTAT.CSV
$stat = substr($stat, 0, -1);

echo $stat;
?>