#cd ~
cd wiringPi/lol_dht22/
# GET DATA FROM SENSOR
get_data(){

	WERTE=$(sudo ./loldht 7 | grep "Temp")
	Hum=$(echo $WERTE | awk '{ print $3}')
	Temp=$(echo $WERTE | awk '{ print $7}')
}

get_data

#CHECK IF DATA IS OUT OF RANGE

check_range(){

#CHECK IF TEMP IS OVER 60.00
num1=$Temp
num2=60.00
if [ -n "$num1" -a -n "$num2" ];then
  result=$(awk -vn1="$num1" -vn2="$num2" 'BEGIN{print (n1>n2)?1:0 }')
  if [ "$result" -eq 1 ];then
   echo "Temp out of range"
   get_data
   else
   echo "Temp in range"
  fi
fi

#CHECK IF HUM IS OVER 99.99
num1=$Hum
num2=99.99
if [ -n "$num1" -a -n "$num2" ];then
  result=$(awk -vn1="$num1" -vn2="$num2" 'BEGIN{print (n1>n2)?1:0 }')
  if [ "$result" -eq 1 ];then
   echo "Hum out of range"
   get_data
   else
   echo "Hum in range"
  fi
fi


#CHECK IF TEMP IS UNDER -15.00
num1=-15.00
num2=$Temp
if [ -n "$num1" -a -n "$num2" ];then
  result=$(awk -vn1="$num1" -vn2="$num2" 'BEGIN{print (n1>n2)?1:0 }')
  if [ "$result" -eq 1 ];then
   echo "Temp out of range"
   get_data
   else
   echo "Temp in range"
  fi
fi

#CHECK IF HUM IS UNDER 10.00
num1=10.00
num2=$Hum
if [ -n "$num1" -a -n "$num2" ];then
  result=$(awk -vn1="$num1" -vn2="$num2" 'BEGIN{print (n1>n2)?1:0 }')
  if [ "$result" -eq 1 ];then
   echo "Hum out of range"
   get_data
   else
   echo "Hum in range"
  fi
fi





}

check_range

datum=$(date +"%Y-%m-%d %T")

cd ~
echo "$Hum"",""$Temp"",""$datum""" >> /home/pi/database.csv
echo $datum
echo $Temp
echo $Hum
