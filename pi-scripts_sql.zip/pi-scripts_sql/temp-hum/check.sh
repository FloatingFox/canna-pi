ping -q -c3 <ip-address> > /dev/null

if [ $? -eq 0 ]
then
	./writeDB.sh
fi
