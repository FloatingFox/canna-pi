mysql -u<username> -p<password> -h <ip-address> --port <port> --local-infile << END

USE <database>
LOAD DATA LOCAL INFILE '/home/pi/database.csv'
INTO TABLE <table> 
FIELDS TERMINATED BY ',' 
LINES TERMINATED BY '\n'
(humidity, temperature, datetime)SET record_id = NULL;

END

if [ "$?" -ne 0 ];then
echo "Errorcode $? while writing to Database"
else
echo "No errors"
rm database.csv
fi


