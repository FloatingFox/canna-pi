<?php 
#error_reporting(E_ALL | E_STRICT);

$lti = $_GET["lti"];
switch ($lti) {
        case 0:
		    exec(" /home/pi/ltioff.sh");
            echo "LTI off";
        break;
        case 80:
		    exec("/home/pi/lti80.sh");
            echo "LTI 80";
        break;
        case 100:
		    exec("/home/pi/lti100.sh");
            echo "LTI 100";
        break;
        case 120:
		    exec("/home/pi/lti120.sh");
			echo "LTI 120";
        break;
        case 150:
		    exec("/home/pi/lti150.sh");
            echo "LTI 150";
        break;
        case 170;
		    exec("/home/pi/lti170.sh");
            echo "LTI 170";
        break;
	    case 190:
		    exec("/home/pi/lti190.sh");
            echo "LTI 190";
        break;	
}
?>
