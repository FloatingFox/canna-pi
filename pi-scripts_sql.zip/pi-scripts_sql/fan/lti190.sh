gpio write 6 1
gpio write 5 1
gpio write 4 1
gpio write 1 1
gpio write 0 1
gpio write 2 1
rm /home/pi/ltistat.csv
echo "190" >> /home/pi/ltistat.csv

