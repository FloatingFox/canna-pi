gpio write 6 1
gpio write 5 1
gpio write 4 1
gpio write 1 1
gpio write 0 1
gpio write 2 0
rm /home/pi/ltistat.csv
echo "170" >> /home/pi/ltistat.csv

