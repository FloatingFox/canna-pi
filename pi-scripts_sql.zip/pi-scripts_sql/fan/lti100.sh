gpio write 6 1
gpio write 5 1
gpio write 4 0
gpio write 1 0
gpio write 0 0
gpio write 2 0
rm /home/pi/ltistat.csv
echo "100" >> /home/pi/ltistat.csv