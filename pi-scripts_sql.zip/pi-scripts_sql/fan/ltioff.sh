gpio write 6 0
gpio write 5 0
gpio write 4 0
gpio write 1 0
gpio write 0 0
gpio write 2 0
sudo rm  ltistat.csv
echo "0" >> /home/pi/ltistat.csv
